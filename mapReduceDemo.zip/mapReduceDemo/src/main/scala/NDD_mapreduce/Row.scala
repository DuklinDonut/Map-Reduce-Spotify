package NDD_mapreduce

/**
 * An input or output row, in a MapReduce job
 * @author Anne-Cecile Caron
 */
trait Row extends Serializable
